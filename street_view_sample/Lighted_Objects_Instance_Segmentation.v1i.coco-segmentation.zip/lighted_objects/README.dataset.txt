# Lighted_Objects_Instance_Segmentation > 2023-01-30 4:16pm
https://universe.roboflow.com/national-university-of-singapore-asnw5/lighted_objects_instance_segmentation

Provided by a Roboflow user
License: CC BY 4.0

